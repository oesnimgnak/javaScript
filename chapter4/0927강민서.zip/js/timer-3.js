// 5초 후에 환영 인사 출력
setTimeout(() => {
    console.log("환영합니다.");
}, 5000);