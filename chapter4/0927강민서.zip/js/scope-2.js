var hi = "hello";       //전역 변수

function greeting() {
    console.log(hi);
}

greeting();